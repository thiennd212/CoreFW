﻿namespace CoreFW.Blazor.Menus;

public class CoreFWMenus
{
    private const string Prefix = "CoreFW";
    public const string Home = Prefix + ".Home";

    //Add your menu items here...

}
