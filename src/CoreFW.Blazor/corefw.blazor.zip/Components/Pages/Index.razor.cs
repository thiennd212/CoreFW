﻿namespace CoreFW.Blazor.Pages;

public partial class Index
{

}
